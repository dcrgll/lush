export function addToCart() {
  window.alert('just kidding')
}
